package in.shan5a6.myweb.controller;
/*
 * 
 */
public class Calculator {
	/*
	 * @param i
	 * @param j
	 * @return int
	 */
	public int add(int i, int j){
		return i+j;
	}
	public int multiply(int i, int j){
		return i*j;
	}
}
